package blog;

public class CateBean {
	private String blogCateName;
	private int blogCateNum;
	
	public int getBlogCateNum() {
		return blogCateNum;
	}
	public void setBlogCateNum(int blogCateNum) {
		this.blogCateNum = blogCateNum;
	}
	public String getBlogCateName() {
		return blogCateName;
	}
	public void setBlogCateName(String blogCateName) {
		this.blogCateName = blogCateName;
	}
}
